An advanced, but easy to use foursquare wrapper library that handles OAuth, automatic retries, and other niceties.

For usage, see: http://github.com/mLewisLogic/foursquare